<?php
/**
 * Provides code to be executed during the module uninstallation
 *
 * @see uninstall_plugin()
 *
 * @package    mod_wrtcvr
 * @copyright  2017 UPMC
 */

/**
 * Custom uninstallation procedure
 */
function xmldb_wrtcvr_uninstall() {
    return true;
}
