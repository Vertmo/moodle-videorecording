<?php
/**
 * Internal library of functions for module wrtcvr
 *
 * All the wrtcvr specific functions, needed to implement the module
 * logic, should go here. Never include this file from your lib.php!
 *
 * @package    mod_wrtcvr
 * @copyright  2017 UPMC
 */

defined('MOODLE_INTERNAL') || die();

/*
 * Does something really useful with the passed things
 *
 * @param array $things
 * @return object
 *function wrtcvr_do_something_useful(array $things) {
 *    return new stdClass();
 *}
 */
